// some js filarish with 
// spellarimisk errarto
