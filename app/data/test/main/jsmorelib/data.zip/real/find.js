// that would destroy case senstitivity in URL's
