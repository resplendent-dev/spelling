/* Simple sampol with makstakes
 */
