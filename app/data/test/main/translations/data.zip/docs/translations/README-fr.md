Cet outil permet d'automatiser le processus de détection.

La traduction automatique neuronale par google translate est très pratique.
