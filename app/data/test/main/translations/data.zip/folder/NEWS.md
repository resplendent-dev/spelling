Neews sppaling errrors should be ignored.
