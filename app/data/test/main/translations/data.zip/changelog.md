Chinglog spalling erriy should be ignored.
