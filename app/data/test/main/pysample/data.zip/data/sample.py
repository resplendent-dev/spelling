"""
Module docstrang
"""

# Some spelling errars in a camment

class O(object):
    """
    My class typi
    """

