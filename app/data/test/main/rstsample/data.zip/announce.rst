Annuncecrst spaling erroy should be ignored.
