Neewsrst sppaling errrors should be ignored.
